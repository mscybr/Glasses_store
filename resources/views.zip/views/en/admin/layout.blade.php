<!DOCTYPE html>
<html lang="en">
<head>
    @include('en.store.head')
</head>
<body class="animsition">

    @include("en.store.nav")
    @yield("content")
    @include("en.store.footer")

</body>
</html>