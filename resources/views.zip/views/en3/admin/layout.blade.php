<!DOCTYPE html>
<html lang="en">
<head>
    @include('en.admin.head')
</head>
<body class="animsition">

    @include("en.admin.nav")
    @yield("content")
    @include("en.admin.footer")

</body>
</html>